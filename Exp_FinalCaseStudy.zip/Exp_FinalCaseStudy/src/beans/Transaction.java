package beans;

//import java.sql.Date;

public class Transaction {

	
	String transid;
	int custid;
	String vendor;
	int transamount;
	String tdate;
	String loc;
	String cardno;
	// int CurrentBal;
	String plan;
	
	public Transaction(String transid,  String vendor,String cardno,String tdate,String loc,  int transamount,int custid,  String plan) 
	{
		super();
		this.cardno = cardno;
		this.custid = custid;
		this.loc = loc;
		this.plan = plan;
		this.tdate = tdate;
		this.transamount = transamount;
		this.transid = transid;
		this.vendor = vendor;
		
	}
	public String getTransid() {
		return transid;
	}
	public int getCustid() {
		return custid;
	}
	public String getVendor() {
		return vendor;
	}
	public int getTransamount() {
		return transamount;
	}
	public String getTdate() {
		return tdate;
	}
	public String getLoc() {
		return loc;
	}
	public String getCardno() {
		return cardno;
	}
	public String getPlan() {
		// TODO Auto-generated method stub
		return plan;
	}

/*	public int getCurrentBal() {
		return CurrentBal;
	}
	
	
	public void Balance(int a) {
		this.CurrentBal=CurrentBal-a;
	}
	*/
}
