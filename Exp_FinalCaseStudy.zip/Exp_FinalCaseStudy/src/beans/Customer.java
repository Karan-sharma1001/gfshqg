package beans;

public class Customer {
	
	int cid;
	String cname;
	String email;
	int mobno;


	public Customer(int mobno, int cid, String cname, String email) {
		super();
		this.mobno = mobno;
		this.cid = cid;
		this.cname = cname;
		this.email = email;
	}
	public int getCid() {
		return cid;
	}
	public String getCname() {
		return cname;
	}
	public String getEmail() {
		return email;
	}
	public int getmobno() {
		return mobno;
	}

	

}
