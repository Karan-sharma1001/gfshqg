
package beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;

public class TestConnection {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int year = 2011;
		int month = 5;
		int dayOfMonth = 20;
		Date dt=new Date();
		int a=dt.getDate();
			
			Calendar c= Calendar.getInstance();
			c.set(Calendar.YEAR, year);
			c.set(Calendar.MONTH, month);
			c.set(Calendar.DAY_OF_MONTH, dayOfMonth);

			// and get that as a Date
			Date dateSpecified = c.getTime();
System.out.println(dt);
System.out.println(a);
		
	}

}
