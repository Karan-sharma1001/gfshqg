package validation;

import java.sql.*;

import beans.JdbcConnection;
import beans.Transaction;

public class TransactionValidateImpl implements TransactionValidate{
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	JdbcConnection db=new JdbcConnection();

	public int addTransaction(Transaction ts) {
		int a=0,b=0,c=0;
		
		
		try {
			con=db.getConnection();
			pst=con.prepareStatement("select creditcardno,plantype from Creditcards c where c.cardno=? and c.plantype=?");
			pst.setString(1, ts.getCardno());
			pst.setString(2, ts.getPlan());
			rs=pst.executeQuery();
			
			if(rs.next()){
				a=1;
			}
			else{
				a=0;
			}
			pst.close();
			
			pst=con.prepareStatement("select customerid from userdetails where customerid=?");
			pst.setInt(1, ts.getCustid());
			rs=pst.executeQuery();
			if(rs.next()){
				b=1;
			}
			else{
				b=0;
			}
			pst.close();con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c=a+b;
		return c;
	}

	


	public String checkTransaction(String id) {
		String res=null;	
		
		try {
			con=db.getConnection();
			pst=con.prepareStatement("select * from transactioninfo where transactionid=?");
			pst.setString(1, id);
			rs=pst.executeQuery();
			if(rs.next()){
				res="valid";
			}
			else{
				res="invalid";
			}
			pst.close();con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}

}
