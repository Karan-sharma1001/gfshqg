package validation;

import beans.Login;

public interface LoginValidate {


	public String userLogin(Login cl);
	public String adminLogin(Login al);
	
}
