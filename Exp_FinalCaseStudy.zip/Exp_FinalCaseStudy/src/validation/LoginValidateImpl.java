package validation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import beans.Login;
import beans.JdbcConnection;
public class LoginValidateImpl implements LoginValidate{


	public String userLogin(Login cl) {
		String res=null;
		Connection con=null;
		PreparedStatement pst;
		ResultSet rs;
		JdbcConnection db=new JdbcConnection();
		con=db.getConnection();
		try {
			pst=con.prepareStatement("select * from customerlogin where userid=? and password=?");
			pst.setInt(1, cl.getUser_id());
			pst.setString(2, cl.getPassword());
			rs=pst.executeQuery();
			if(rs.next()){
				res="valid";	
			}
			else{
				res="invalid";
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}


	public String adminLogin(Login al) {
		String res=null;
		Connection con=null;
		PreparedStatement pst;
		ResultSet rs;
		JdbcConnection db=new JdbcConnection();
		con=db.getConnection();
		try {
			pst=con.prepareStatement("select * from adminlogin where adminid=? and password=?");
			pst.setInt(1, al.getUser_id());
			pst.setString(2, al.getPassword());
			rs=pst.executeQuery();
			if(rs.next()){
				res="valid";	
			}
			else{
				res="invalid";
			}
			rs.close();
			pst.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return res;
	}

}
