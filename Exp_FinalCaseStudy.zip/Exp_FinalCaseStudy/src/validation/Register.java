package validation;

import beans.Customer;
import beans.Login;

public interface Register {
	
	public String register(Customer c);

	
}
