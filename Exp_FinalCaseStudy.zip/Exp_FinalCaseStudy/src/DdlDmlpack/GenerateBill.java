package DdlDmlpack;

import beans.Bill;

public interface GenerateBill {
	
	public Bill genBill(String id);
		
	

}
