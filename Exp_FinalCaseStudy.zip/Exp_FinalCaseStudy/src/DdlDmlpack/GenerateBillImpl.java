package DdlDmlpack;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import beans.Bill;
import beans.JdbcConnection;

public class GenerateBillImpl implements GenerateBill{


	public Bill genBill(String id) {
		double total=0;
		double discount=0;
		double limit=0;
		double billamt=0;
		double balance=0;
		Bill b=null;
		String plan=null;
		Connection con;
		PreparedStatement pst;
		CallableStatement cst;
        ResultSet rs;
		JdbcConnection db=new JdbcConnection();
		con=db.getConnection();
		try {
			pst=con.prepareStatement("select plantype from Accountdetails a,creditcards c,plans p where customerid=? and c.creditcardno=a.creditcardno and c.planid=p.planid");
			int cid=Integer.parseInt(id);
			pst.setInt(1, cid);
			rs=pst.executeQuery();
			if(rs.next()){
				plan=rs.getString(1);			
			}
			rs.close();
			pst.close();
			
			cst=con.prepareCall("{call billamount(?,?)}");
			cst.setInt(1, cid);
			cst.registerOutParameter(2, Types.INTEGER);
			cst.executeUpdate();
		
				 total=cst.getInt(2);
				 if(plan.equalsIgnoreCase("platinum")){
					 discount=total*0.05;
					billamt=total-discount;
					limit=75000;
				 }
				 else if(plan.equalsIgnoreCase("gold")){
					 billamt=total;
					 limit=60000;
				 }
				 else if(plan.equalsIgnoreCase("silver")){
					 billamt=total;
					 limit=50000;
				 }

			 balance=limit-billamt;
		 b=new Bill();
			 b.setTotal(total);
			 b.setDiscount(discount);
			 b.setBillamt(billamt);
			 b.setPlan(plan);
			 b.setBalance(balance);
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return b;
	}

}
