package DdlDmlpack;

import java.sql.*;

import beans.Customer;
import beans.JdbcConnection;

public class Registercustomer {
	
	JdbcConnection db=new JdbcConnection();
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String plan;
	int n,m,s;
	public int register(Customer c,String pswd){
		con=db.getConnection();
		try {
			pst=con.prepareStatement("select p.plantype from Creditcards c where creditcardno=? ");
			pst.setInt(1, c.getmobno());
			rs=pst.executeQuery();
			if(rs.next()){
				plan=rs.getString(1);
			}
			rs.close();
			pst.close();
			
			pst=con.prepareStatement("insert into userdetails values(?,?,?,?,?)");
			pst.setInt(1,c.getCid());
			pst.setString(2,c.getCname());
			pst.setString(3,c.getEmail());
			pst.setInt(4,c.getmobno());
			pst.setString(5, plan);
			n=pst.executeUpdate();
			pst.close();
			
			pst=con.prepareStatement("insert into customerlogin values(?,?)");
			pst.setInt(1, c.getCid());
			pst.setString(2,pswd);
			m=pst.executeUpdate();
			pst.close();
			s=n+m;
			
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s;
		
	}

}
