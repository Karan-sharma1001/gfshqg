package com.techm.dto;

public class User1 {

	private String UserName;
	private String Gender;
	private String City;
	private String State;
	private String PinCode;
	private String EmailId;
	private long MobileNo;
	private String Password;
	public User1(String userName, String gender, String city,
			String state, String pinCode, String emailId, long mobileNo,
			String password) {
		super();
		UserName = userName;
		Gender = gender;
		City = city;
		State = state;
		PinCode = pinCode;
		EmailId = emailId;
		MobileNo = mobileNo;
		Password = password;
	}
	
	
	public User1(String userName, String gender, String city, String state,
			String pinCode, String emailId, long mobileNo) {
		super();
		UserName = userName;
		Gender = gender;
		City = city;
		State = state;
		PinCode = pinCode;
		EmailId = emailId;
		MobileNo = mobileNo;
	}


	/*public User1(int customer_id, String customer_name, int initialAmount,
			int purchasedShares, int soldShares, int balanceAmount) {
		// TODO Auto-generated constructor stub
	}*/


	public User1(int i, String userType, int j, int k, int l, int m) {
		// TODO Auto-generated constructor stub
	}


	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPinCode() {
		return PinCode;
	}
	public void setPinCode(String pinCode) {
		PinCode = pinCode;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public long getMobileNo() {
		return MobileNo;
	}
	public void setMobileNo(int mobileNo) {
		MobileNo = mobileNo;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}


	public User1 validateUser(String userID, String password2, String userType) {
		// TODO Auto-generated method stub
		
		return null;
	}
	
	
}
