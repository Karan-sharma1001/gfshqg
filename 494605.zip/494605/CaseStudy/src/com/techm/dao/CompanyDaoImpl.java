package com.techm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.techm.dto.Company;
import com.techm.util.JdbcConnection;

public class CompanyDaoImpl implements CompanyDao{

	public boolean insertcompany(Company p) {
		// TODO Auto-generated method stub
		
				Connection conn=JdbcConnection.getConnection();
				String query="insert into Company values(?,?,?)";
				PreparedStatement pst;
				try {
					pst = conn.prepareStatement(query);
					pst.setInt(1,p.getCompany_id());
					pst.setString(2,p.getCompany_name());
					pst.setInt(3, p.getNoOfShares());
					
					int rec=pst.executeUpdate();
					if(rec==1)
					{
						return true;
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally{
					try {
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				return false;
	}



}
