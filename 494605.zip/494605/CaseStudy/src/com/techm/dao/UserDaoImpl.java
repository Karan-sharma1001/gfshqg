package com.techm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.techm.dto.User1;
import com.techm.util.JdbcConnection;

public class UserDaoImpl implements UserDao{

	public boolean insert(User1 p) {
		Connection conn=JdbcConnection.getConnection();
		String query="insert into User1 values(?,?,?,?,?,?,?,?)";
		PreparedStatement pst1;
		try {
			pst1 = conn.prepareStatement(query);
			pst1.setString(1,p.getUserName());
			pst1.setString(2,p.getGender());
			pst1.setString(3, p.getCity());
			pst1.setString(4, p.getState());
			pst1.setString(5, p.getPinCode());
			pst1.setString(6, p.getEmailId());
			pst1.setLong(7, p.getMobileNo());
			pst1.setString(8, p.getPassword());
			
			int rec=pst1.executeUpdate();
			if(rec==1)
			{
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return true;
	}


	/*public List<User1> display() {
		// TODO Auto-generated method stub
		ArrayList<User1> aList= new ArrayList<User1>();
		Connection conn=JdbcConnection.getConnection();
		String query="select * from Login";
		PreparedStatement pst;
		try {
			pst=conn.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
				String m_UserName=rs.getString(1);
				String m_Gender=rs.getString(2);
				String m_City=rs.getString(3);
				String m_State=rs.getString(4);
				String m_PinCode=rs.getString(5);
				String m_EmailId=rs.getString(6);
				long m_MobileNo=Long.parseLong(rs.getString(7));
				String m_password=rs.getString(8);
	
				//Employee e= new Employee(m_name, m_dob, m_gender, m_qualification, m_skill, m_qualification, m_email_id, Integer.parseInt(m_mobile), m_address, m_password);
				User1 u= new User1(m_UserName, m_Gender, m_City, m_State, m_PinCode, m_EmailId,m_MobileNo, m_password);
				aList.add(u);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return aList;
	}*/

	
	
}

	
