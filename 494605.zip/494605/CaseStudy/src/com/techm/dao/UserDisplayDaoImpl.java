package com.techm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.techm.dto.User1;
import com.techm.util.JdbcConnection;

public class UserDisplayDaoImpl implements UserDispalyDao {

	public ArrayList<User1> display(User1 u) {
		ArrayList<User1> view = new ArrayList<User1>();
		
		Connection conn = JdbcConnection.getConnection();
		try {
			Statement st = conn.createStatement();
			String query = "select * from User1 where UserName=? and Password=?";
			ResultSet rs = st.executeQuery(query);
			int Customer_id=rs.getInt(4);
			PreparedStatement pst=null;
			pst=conn.prepareStatement("select * from Customer where Customer_id=?");
			pst.setInt(1, Customer_id);
			rs=pst.executeQuery();
			
			while(rs.next()){
				
				int customer_id = rs.getInt(1);
				String Customer_name = rs.getString(2);
				int InitialAmount = rs.getInt(3);
				int PurchasedShares = rs.getInt(4);
				int SoldShares = rs.getInt(5);
				int BalanceAmount = rs.getInt(6);
				
				
				User1 u1 =new User1(Customer_id, Customer_name, InitialAmount, PurchasedShares, SoldShares, BalanceAmount);				
				 
				
				view.add(u1);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return view;
	}

	

}
